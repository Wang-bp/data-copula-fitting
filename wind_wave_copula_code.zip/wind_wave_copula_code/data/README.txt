Place the four site-level hindcast arrays in this directory using these names:
  time_station_20yrs_2.npy
  u10_station_20yrs_2.npy
  hs_station_20yrs_2.npy
  tp_station_20yrs_2.npy

The time variable is interpreted as hours since 1970-01-01 00:00:00
with the proleptic Gregorian calendar.

Optional model-validation files can be placed here as well. They are not
required for the core probability / copula / return-period calculations.
