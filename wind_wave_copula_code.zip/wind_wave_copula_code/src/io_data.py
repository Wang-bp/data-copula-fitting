from pathlib import Path
import numpy as np
import pandas as pd

EPOCH = "1970-01-01 00:00:00"


def load_hindcast(data_dir):
    """Load the four hourly .npy arrays and return a common-valid DataFrame."""
    data_dir = Path(data_dir)
    time = np.load(data_dir / "time_station_20yrs_2.npy")
    u10 = np.load(data_dir / "u10_station_20yrs_2.npy")
    hs = np.load(data_dir / "hs_station_20yrs_2.npy")
    tp = np.load(data_dir / "tp_station_20yrs_2.npy")
    if not (len(time) == len(u10) == len(hs) == len(tp)):
        raise ValueError("The four input arrays must have identical length.")
    dt = pd.to_datetime(time, unit="h", origin=EPOCH)
    df = pd.DataFrame({"time": dt, "U10": u10, "Hs": hs, "Tp": tp})
    df = df.replace([np.inf, -np.inf], np.nan).dropna().sort_values("time").reset_index(drop=True)
    return df


def save_csv(df, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
