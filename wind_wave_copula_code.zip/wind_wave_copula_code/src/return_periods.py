import numpy as np
from scipy import optimize
from .copulas import model_cdf


def univariate_quantile(marginal, T_years, mu_years=1/12):
    q=1-mu_years/T_years
    return float(marginal.ppf(q)), float(q)


def exceedance_prob(model,u,v,definition="OR"):
    C=float(model_cdf(model,float(u),float(v)))
    if definition.upper()=="OR":
        return max(1-C,1e-15)
    if definition.upper()=="AND":
        return max(1-u-v+C,1e-15)
    raise ValueError("definition must be OR or AND")


def joint_return_period(model,u,v,definition="OR",mu_years=1/12):
    return float(mu_years/exceedance_prob(model,u,v,definition))


def fixed_equal_univariate_thresholds(mx,my,T_years,mu_years=1/12):
    x,qx=univariate_quantile(mx,T_years,mu_years)
    y,qy=univariate_quantile(my,T_years,mu_years)
    return x,y,qx,qy


def balanced_probability_q(model,T_years,definition="OR",mu_years=1/12):
    target=mu_years/T_years
    if definition.upper()=="OR":
        f=lambda q: 1-float(model_cdf(model,q,q))-target
    elif definition.upper()=="AND":
        f=lambda q: 1-2*q+float(model_cdf(model,q,q))-target
    else: raise ValueError(definition)
    return float(optimize.brentq(f,1e-8,1-1e-10,maxiter=500))


def balanced_physical_point(model,mx,my,T_years,definition="OR",mu_years=1/12):
    q=balanced_probability_q(model,T_years,definition,mu_years)
    return q,float(mx.ppf(q)),float(my.ppf(q))
