from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import subprocess
import tempfile
import numpy as np
from scipy import optimize, stats

_EPS = 1e-12


def sj_dpi_bandwidth_r(values, r_script):
    """Call R's stats::bw.SJ(..., method='dpi').

    This is the exact selector described in the manuscript. R is only needed to
    estimate the bandwidth; all subsequent KDE evaluation is performed in Python.
    """
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        np.savetxt(f.name, values)
        name = f.name
    try:
        out = subprocess.check_output(["Rscript", str(r_script), name], text=True).strip()
        return float(out.splitlines()[-1])
    finally:
        Path(name).unlink(missing_ok=True)


@dataclass
class LogKDE:
    x: np.ndarray
    h: float

    @classmethod
    def fit(cls, x, h=None, r_script=None):
        x = np.asarray(x, dtype=float)
        x = x[np.isfinite(x) & (x > 0)]
        z = np.log(x)
        if h is None:
            if r_script is None:
                raise ValueError("Supply h or r_script for Sheather-Jones DPI bandwidth.")
            h = sj_dpi_bandwidth_r(z, r_script)
        return cls(x=x, h=float(h))

    @property
    def z(self):
        return np.log(self.x)

    def cdf(self, q):
        q = np.asarray(q, dtype=float)
        flat = q.ravel()
        out = np.empty_like(flat)
        z = self.z
        for i, val in enumerate(flat):
            if val <= 0:
                out[i] = 0.0
            else:
                out[i] = np.mean(stats.norm.cdf((np.log(val) - z) / self.h))
        return out.reshape(q.shape) if q.ndim else float(out[0])

    def pdf(self, q):
        q = np.asarray(q, dtype=float)
        flat = q.ravel()
        out = np.empty_like(flat)
        z = self.z
        for i, val in enumerate(flat):
            if val <= 0:
                out[i] = 0.0
            else:
                out[i] = np.mean(stats.norm.pdf((np.log(val) - z) / self.h)) / (self.h * val)
        return out.reshape(q.shape) if q.ndim else float(out[0])

    def ppf(self, p):
        p = np.asarray(p, dtype=float)
        flat = p.ravel()
        out = np.empty_like(flat)
        lo = max(np.min(self.x) * 1e-4, 1e-12)
        hi0 = np.max(self.x)
        for i, prob in enumerate(flat):
            prob = float(np.clip(prob, _EPS, 1-_EPS))
            hi = hi0
            while self.cdf(hi) < prob:
                hi *= 1.5
            out[i] = optimize.brentq(lambda xx: self.cdf(xx) - prob, lo, hi,
                                     xtol=1e-10, rtol=1e-10, maxiter=200)
        return out.reshape(p.shape) if p.ndim else float(out[0])


@dataclass
class KernelPareto:
    x: np.ndarray
    threshold_q: float
    threshold: float
    p_u: float
    body: stats.gaussian_kde
    xi: float
    beta: float

    @classmethod
    def fit(cls, x, threshold_q=0.95):
        x = np.asarray(x, dtype=float)
        x = x[np.isfinite(x)]
        u = float(np.quantile(x, threshold_q))
        body_x = x[x <= u]
        body = stats.gaussian_kde(body_x, bw_method="silverman")
        excess = x[x > u] - u
        xi, loc, beta = stats.genpareto.fit(excess, floc=0.0)
        return cls(x=x, threshold_q=float(threshold_q), threshold=u,
                   p_u=float(threshold_q), body=body, xi=float(xi), beta=float(beta))

    def _body_cdf_raw(self, q):
        return self.body.integrate_box_1d(-np.inf, float(q))

    def cdf(self, q):
        q = np.asarray(q, dtype=float)
        flat = q.ravel()
        out = np.empty_like(flat)
        Fu = max(self._body_cdf_raw(self.threshold), _EPS)
        for i, val in enumerate(flat):
            if val <= self.threshold:
                out[i] = self.p_u * self._body_cdf_raw(val) / Fu
            else:
                g = stats.genpareto.cdf(val - self.threshold, c=self.xi, loc=0, scale=self.beta)
                out[i] = self.p_u + (1-self.p_u)*g
        return out.reshape(q.shape) if q.ndim else float(out[0])

    def pdf(self, q):
        q = np.asarray(q, dtype=float)
        flat = q.ravel()
        out = np.empty_like(flat)
        Fu = max(self._body_cdf_raw(self.threshold), _EPS)
        for i, val in enumerate(flat):
            if val <= self.threshold:
                out[i] = self.p_u * float(self.body(val)[0]) / Fu
            else:
                out[i] = (1-self.p_u)*stats.genpareto.pdf(val-self.threshold, c=self.xi, loc=0, scale=self.beta)
        return out.reshape(q.shape) if q.ndim else float(out[0])

    def ppf(self, p):
        p = np.asarray(p, dtype=float)
        flat = p.ravel()
        out = np.empty_like(flat)
        lo = min(np.min(self.x), self.threshold) - 5*np.std(self.x)
        for i, prob in enumerate(flat):
            prob = float(np.clip(prob, _EPS, 1-_EPS))
            if prob > self.p_u:
                pp = (prob-self.p_u)/(1-self.p_u)
                out[i] = self.threshold + stats.genpareto.ppf(pp, c=self.xi, loc=0, scale=self.beta)
            else:
                out[i] = optimize.brentq(lambda xx: self.cdf(xx)-prob, lo, self.threshold, maxiter=200)
        return out.reshape(p.shape) if p.ndim else float(out[0])


@dataclass
class GEV:
    x: np.ndarray
    shape_xi: float
    loc: float
    scale: float

    @classmethod
    def fit(cls, x):
        x = np.asarray(x, dtype=float)
        x = x[np.isfinite(x)]
        # scipy genextreme uses c = -xi relative to the common EVT sign convention.
        c, loc, scale = stats.genextreme.fit(x)
        return cls(x=x, shape_xi=float(-c), loc=float(loc), scale=float(scale))

    @property
    def scipy_c(self):
        return -self.shape_xi

    def cdf(self, q):
        return stats.genextreme.cdf(q, c=self.scipy_c, loc=self.loc, scale=self.scale)

    def pdf(self, q):
        return stats.genextreme.pdf(q, c=self.scipy_c, loc=self.loc, scale=self.scale)

    def ppf(self, p):
        return stats.genextreme.ppf(p, c=self.scipy_c, loc=self.loc, scale=self.scale)


def anderson_darling_statistic(x, cdf):
    x = np.sort(np.asarray(x, dtype=float))
    n = len(x)
    F = np.clip(np.asarray(cdf(x), dtype=float), _EPS, 1-_EPS)
    i = np.arange(1, n+1)
    return float(-n - np.mean((2*i-1)*(np.log(F) + np.log(1-F[::-1]))))


def ks_statistic(x, cdf):
    x = np.sort(np.asarray(x, dtype=float))
    n = len(x)
    F = np.asarray(cdf(x), dtype=float)
    Dp = np.max(np.arange(1,n+1)/n - F)
    Dm = np.max(F - np.arange(0,n)/n)
    return float(max(Dp,Dm))


def mean_residual_life(x, qs=np.arange(0.90, 0.996, 0.005)):
    x = np.asarray(x, dtype=float)
    rows=[]
    for q in qs:
        u=np.quantile(x,q)
        exc=x[x>u]-u
        rows.append((q,u,len(exc),float(np.mean(exc)) if len(exc) else np.nan))
    return rows


def gpd_parameter_stability(x, qs=np.arange(0.90, 0.996, 0.005)):
    x=np.asarray(x,dtype=float)
    rows=[]
    for q in qs:
        u=np.quantile(x,q); exc=x[x>u]-u
        if len(exc)<5:
            rows.append((q,u,len(exc),np.nan,np.nan)); continue
        xi,_,beta=stats.genpareto.fit(exc,floc=0.0)
        rows.append((q,u,len(exc),float(xi),float(beta)))
    return rows
