import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.diagnostic import acorr_ljungbox
from .copulas import (fit_single,fit_mixed,information_criteria,sn_statistic,
                      model_logpdf,sample_model,pseudo_observations)

CANDIDATES=["Gaussian","StudentT","Frank","Clayton","Gumbel"]


def fit_all_copulas(x,y,include_mixed=True,seed=20260911):
    uv=pseudo_observations(x,y)
    models=[]
    for name in CANDIDATES:
        m=fit_single(name,uv); m.update(information_criteria(m["loglik"],len(uv),len(m["params"])))
        m["Sn"]=sn_statistic(uv,m); models.append(m)
    if include_mixed:
        m=fit_mixed(uv,seed); m.update(information_criteria(m["loglik"],len(uv),5)); m["Sn"]=sn_statistic(uv,m); models.append(m)
    return uv,models


def holdout_score(train_x,train_y,test_x,test_y,name,seed=20260911):
    uv_train=pseudo_observations(train_x,train_y)
    # Map test values to empirical training margins for pseudo-observations.
    sx=np.sort(np.asarray(train_x)); sy=np.sort(np.asarray(train_y)); n=len(sx)
    u=(np.searchsorted(sx,test_x,side="right")+.5)/(n+1.0)
    v=(np.searchsorted(sy,test_y,side="right")+.5)/(n+1.0)
    uv_test=np.clip(np.column_stack([u,v]),1e-7,1-1e-7)
    model=fit_mixed(uv_train,seed) if name=="Mixed" else fit_single(name,uv_train)
    return float(np.mean(model_logpdf(model,uv_test))), model


def parametric_bootstrap_pvalue(uv, model, B=100, seed=20260911):
    rng=np.random.default_rng(seed); obs=sn_statistic(uv,model); vals=[]
    for b in range(B):
        sim=sample_model(model,len(uv),rng)
        # rank transform mirrors the estimation procedure
        sim_uv=pseudo_observations(sim[:,0],sim[:,1])
        fitted=fit_mixed(sim_uv,seed+b+1) if model["name"]=="Mixed" else fit_single(model["name"],sim_uv)
        vals.append(sn_statistic(sim_uv,fitted))
    vals=np.asarray(vals)
    p=(1+np.sum(vals>=obs))/(B+1)
    return float(p),vals


def nonparametric_sn_interval(x,y,name,B=100,seed=20260911):
    rng=np.random.default_rng(seed); n=len(x); vals=[]
    for b in range(B):
        idx=rng.integers(0,n,n); uv=pseudo_observations(np.asarray(x)[idx],np.asarray(y)[idx])
        fitted=fit_mixed(uv,seed+b+1000) if name=="Mixed" else fit_single(name,uv)
        vals.append(sn_statistic(uv,fitted))
    uv0=pseudo_observations(x,y)
    fit0=fit_mixed(uv0,seed) if name=="Mixed" else fit_single(name,uv0)
    s0=sn_statistic(uv0,fit0); se=np.std(vals,ddof=1)
    return s0,max(0.0,s0-1.96*se),s0+1.96*se


def serial_diagnostics(series):
    a=np.asarray(series,dtype=float)
    r=float(np.corrcoef(a[:-1],a[1:])[0,1])
    p=float(acorr_ljungbox(a,lags=[1],return_df=True)["lb_pvalue"].iloc[0])
    return r,p


def seasonal_distribution_test(cool,warm):
    z=stats.ks_2samp(cool,warm,alternative="two-sided",method="auto")
    return float(z.statistic),float(z.pvalue)
