import numpy as np
import pandas as pd


def construct_monthly_extreme_pairs(df, require_complete_month=True):
    """Construct the three temporally consistent monthly extreme pairs.

    U10max-Hs and U10max-Tp retain Hs/Tp at the timestamp of monthly U10 max.
    Hsmax-Tp retains Tp at the timestamp of monthly Hs max.
    """
    x = df.copy()
    x["period"] = x["time"].dt.to_period("M")
    rows = []
    for period, g in x.groupby("period", sort=True):
        if require_complete_month:
            expected = period.days_in_month * 24
            if len(g) != expected:
                continue
        iu = g["U10"].idxmax()
        ih = g["Hs"].idxmax()
        rows.append({
            "period": str(period),
            "year": int(period.year),
            "month": int(period.month),
            "U10max": float(x.loc[iu, "U10"]),
            "Hs_at_U10max": float(x.loc[iu, "Hs"]),
            "Tp_at_U10max": float(x.loc[iu, "Tp"]),
            "Hsmax": float(x.loc[ih, "Hs"]),
            "Tp_at_Hsmax": float(x.loc[ih, "Tp"]),
            "time_U10max": x.loc[iu, "time"],
            "time_Hsmax": x.loc[ih, "time"],
        })
    return pd.DataFrame(rows)


def add_regime(monthly):
    out = monthly.copy()
    out["regime"] = np.where(out["month"].isin([11, 12, 1, 2, 3]),
                             "cool", "warm")
    return out
