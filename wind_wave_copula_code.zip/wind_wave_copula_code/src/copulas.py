from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy import optimize, stats
from scipy.special import logsumexp
from statsmodels.distributions.copula.api import (
    GaussianCopula, StudentTCopula, ClaytonCopula, GumbelCopula, FrankCopula
)

EPS=1e-10


def pseudo_observations(x, y):
    n=len(x)
    u=stats.rankdata(x, method="average")/(n+1.0)
    v=stats.rankdata(y, method="average")/(n+1.0)
    return np.column_stack([u,v])


def copula_object(name, params):
    if name == "Gaussian": return GaussianCopula(float(params[0]))
    if name == "StudentT": return StudentTCopula(float(params[0]), df=float(params[1]))
    if name == "Gumbel": return GumbelCopula(float(params[0]))
    if name == "Clayton": return ClaytonCopula(float(params[0]))
    if name == "Frank": return FrankCopula(float(params[0]))
    raise KeyError(name)


def cdf_single(name, params, u, v):
    pts=np.column_stack([np.atleast_1d(u),np.atleast_1d(v)])
    if name=="StudentT":
        rho,nu=float(params[0]),float(params[1])
        q=stats.t.ppf(np.clip(pts,EPS,1-EPS),df=nu)
        vals=np.array([stats.multivariate_t.cdf(row, shape=[[1,rho],[rho,1]], df=nu, random_state=np.random.default_rng(314159)) for row in q])
    else:
        vals=np.asarray(copula_object(name,params).cdf(pts))
    if np.ndim(u)==0 and np.ndim(v)==0:
        return float(vals.reshape(-1)[0])
    return vals


def logpdf_single(name, params, uv):
    return np.asarray(copula_object(name,params).logpdf(np.clip(uv,EPS,1-EPS)))


def _nll(params, name, uv):
    try:
        lp=logpdf_single(name,params,uv)
        return 1e100 if np.any(~np.isfinite(lp)) else float(-lp.sum())
    except Exception:
        return 1e100


def fit_single(name, uv):
    tau=float(stats.kendalltau(uv[:,0],uv[:,1]).statistic)
    rho0=float(np.clip(np.sin(np.pi*tau/2),-.95,.95))
    if name=="Gaussian":
        b=[(-.995,.995)]; x0=[rho0]
    elif name=="StudentT":
        b=[(-.995,.995),(2.05,100)]; x0=[rho0,8.0]
    elif name=="Gumbel":
        b=[(1.000001,50)]; x0=[max(1.001,1/(1-max(tau,-.99)))]
    elif name=="Clayton":
        b=[(1e-3,50)]; x0=[max(1e-3,2*tau/(1-tau))]
    elif name=="Frank":
        b=[(1e-4,50)]; x0=[max(.1,6*tau/(1-tau*tau+1e-9))]
    else: raise KeyError(name)
    starts=[x0]
    if name=="Frank": starts += [[.5],[2.0],[5.0],[10.0]]
    best=None
    for st in starts:
        r=optimize.minimize(_nll,st,args=(name,uv),method="L-BFGS-B",bounds=b,
                            options={"maxiter":3000,"ftol":1e-12})
        if best is None or r.fun<best.fun: best=r
    return {"name":name,"params":best.x.tolist(),"loglik":float(-best.fun),"success":bool(best.success)}


def _mix_nll_trans(z, uv):
    # positive parameter transforms and 3-way softmax weights
    tg=1+np.exp(z[0]); tc=np.exp(z[1]); tf=np.exp(z[2])
    logits=np.array([z[3],z[4],0.0]); logits-=logits.max()
    w=np.exp(logits); w/=w.sum()
    try:
        lp=np.vstack([
            np.log(w[0])+GumbelCopula(tg).logpdf(uv),
            np.log(w[1])+ClaytonCopula(tc).logpdf(uv),
            np.log(w[2])+FrankCopula(tf).logpdf(uv),
        ])
        s=logsumexp(lp,axis=0)
        return 1e100 if np.any(~np.isfinite(s)) else float(-s.sum())
    except Exception:
        return 1e100


def fit_mixed(uv, random_seed=20260911):
    """Fit Gumbel-Clayton-Frank mixture by common maximum pseudo-likelihood.

    Finite-mixture likelihoods are non-convex. Multiple starts are used; exact
    paper values can instead be supplied from paper_parameters.json for strict
    table/figure reproduction.
    """
    rng=np.random.default_rng(random_seed)
    sg=fit_single("Gumbel",uv)["params"][0]
    sc=fit_single("Clayton",uv)["params"][0]
    sf=fit_single("Frank",uv)["params"][0]
    starts=[]
    for weights in ([.96,.03,.01],[.8,.1,.1],[1/3,1/3,1/3]):
        c=max(weights[2],1e-8)
        starts.append(np.array([np.log(max(sg-1,1e-6)),np.log(sc),np.log(sf),
                                np.log(weights[0]/c),np.log(weights[1]/c)]))
    for _ in range(5):
        starts.append(starts[0] + rng.normal(0,.4,5))
    best=None
    for z0 in starts:
        r=optimize.minimize(_mix_nll_trans,z0,args=(uv,),method="L-BFGS-B",
                            options={"maxiter":5000,"ftol":1e-12})
        if best is None or r.fun<best.fun: best=r
    z=best.x
    theta=[1+np.exp(z[0]),np.exp(z[1]),np.exp(z[2])]
    logits=np.array([z[3],z[4],0.0]); logits-=logits.max(); w=np.exp(logits); w/=w.sum()
    return {"name":"Mixed","theta":[float(x) for x in theta],
            "weights":[float(x) for x in w],"loglik":float(-best.fun),"success":bool(best.success)}


def cdf_mixed(model, u, v):
    w=model["weights"]; th=model["theta"]
    vals=0.0
    if w[0]>0: vals += w[0]*cdf_single("Gumbel",[th[0]],u,v)
    if w[1]>0: vals += w[1]*cdf_single("Clayton",[th[1]],u,v)
    if w[2]>0: vals += w[2]*cdf_single("Frank",[th[2]],u,v)
    return vals


def logpdf_mixed(model, uv):
    terms=[]
    for w,name,theta in zip(model["weights"],["Gumbel","Clayton","Frank"],model["theta"]):
        if w>0 and theta is not None:
            terms.append(np.log(w)+logpdf_single(name,[theta],uv))
    return logsumexp(np.vstack(terms),axis=0)


def information_criteria(loglik, n, k):
    return {"AIC":float(-2*loglik+2*k),"BIC":float(-2*loglik+k*np.log(n))}


def empirical_copula_values(uv):
    n=len(uv)
    out=np.empty(n)
    for i,(u,v) in enumerate(uv):
        out[i]=np.mean((uv[:,0]<=u)&(uv[:,1]<=v))
    return out


def sn_statistic(uv, model):
    ce=empirical_copula_values(uv)
    if model["name"]=="Mixed":
        cm=np.array([cdf_mixed(model,u,v) for u,v in uv])
    else:
        cm=np.array([cdf_single(model["name"],model["params"],u,v) for u,v in uv])
    return float(np.sum((ce-cm)**2))


def model_cdf(model,u,v):
    return cdf_mixed(model,u,v) if model["name"]=="Mixed" else cdf_single(model["name"],model["params"],u,v)


def model_logpdf(model,uv):
    return logpdf_mixed(model,uv) if model["name"]=="Mixed" else logpdf_single(model["name"],model["params"],uv)


def sample_model(model,n,rng):
    if model["name"] != "Mixed":
        return copula_object(model["name"],model["params"]).rvs(n,random_state=rng)
    w=np.array(model["weights"]); idx=rng.choice(3,size=n,p=w/w.sum())
    out=np.empty((n,2))
    names=["Gumbel","Clayton","Frank"]
    for j,name in enumerate(names):
        mask=idx==j
        if mask.any():
            theta=model["theta"][j]
            out[mask]=copula_object(name,[theta]).rvs(mask.sum(),random_state=rng)
    return out
