#!/usr/bin/env python
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parent
scripts=[
 "01_prepare_monthly_extremes.py",
 "02_fit_marginals.py",
 "03_fit_copulas.py",
 "04_return_periods.py",
 "05_seasonality.py",
 "06_make_key_figures.py",
]
for s in scripts:
    print("\n===",s,"===")
    subprocess.run([sys.executable,str(ROOT/"scripts"/s)],check=True)
print("\nFinished. Results are in outputs/.")
