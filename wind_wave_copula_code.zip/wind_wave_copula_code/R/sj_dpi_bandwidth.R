#!/usr/bin/env Rscript
# Sheather-Jones direct plug-in bandwidth for Gaussian KDE.
# Input: one-column text/CSV file with numeric values.
# Output: one bandwidth value to stdout.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 1) stop("Usage: Rscript sj_dpi_bandwidth.R values.txt")
x <- scan(args[1], quiet = TRUE)
x <- x[is.finite(x)]
if (length(x) < 2) stop("Need at least two finite values")
h <- bw.SJ(x, method = "dpi")
cat(sprintf("%.17g\n", h))
