#!/usr/bin/env python
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.io_data import load_hindcast
from src.monthly_extremes import construct_monthly_extreme_pairs
from src.marginals import LogKDE,KernelPareto,GEV,ks_statistic,anderson_darling_statistic,mean_residual_life,gpd_parameter_stability

cfg=json.load(open(ROOT/"analysis_config.json"))
reported=json.load(open(ROOT/"paper_parameters.json"))
rscript=ROOT/"R/sj_dpi_bandwidth.R"
df=load_hindcast(ROOT/"data")
monthly=construct_monthly_extreme_pairs(df)

# Hourly marginal diagnostics. R is used for the SJ-DPI selector.
rows=[]
for var in ["U10","Hs","Tp"]:
    x=df[var].to_numpy()
    sj=LogKDE.fit(x,r_script=rscript)
    kp=KernelPareto.fit(x,cfg["kernel_pareto_threshold_quantile"])
    gev=GEV.fit(x)
    for name,model in [("SJ-DPI",sj),("Kernel-Pareto",kp),("GEV",gev)]:
        q95e=abs(float(model.ppf(.95))-float(np.quantile(x,.95)))
        q99e=abs(float(model.ppf(.99))-float(np.quantile(x,.99)))
        rows.append([var,name,len(x),ks_statistic(x,model.cdf),anderson_darling_statistic(x,model.cdf),q95e,q99e])
    pd.DataFrame(mean_residual_life(x),columns=["quantile","threshold","N_exceed","mean_excess"]).to_csv(ROOT/f"outputs/{var}_mrl.csv",index=False)
    pd.DataFrame(gpd_parameter_stability(x),columns=["quantile","threshold","N_exceed","xi","beta"]).to_csv(ROOT/f"outputs/{var}_gpd_stability.csv",index=False)
    print(var,"SJ-DPI h(log)=",sj.h,"KP threshold=",kp.threshold,"xi=",kp.xi,"beta=",kp.beta)

pd.DataFrame(rows,columns=["variable","model","N","KS","AD","q95_error","q99_error"]).to_csv(ROOT/"outputs/hourly_marginal_gof.csv",index=False)

# Monthly marginals used for return-period analysis. Reported SJ bandwidths are
# supplied for strict reproducibility of the manuscript's table values.
cols=["U10max","Hs_at_U10max","Tp_at_U10max","Hsmax","Tp_at_Hsmax"]
par=[]
for col in cols:
    x=monthly[col].to_numpy(); h=reported["monthly_sj_dpi_log_bandwidth"][col]
    sj=LogKDE.fit(x,h=h); kp=KernelPareto.fit(x,.95); gev=GEV.fit(x)
    par.append([col,len(x),sj.h,kp.threshold,kp.xi,kp.beta,gev.loc,gev.scale,gev.shape_xi])
pd.DataFrame(par,columns=["sample","N","SJ_h_log","KP_u","KP_xi","KP_beta","GEV_mu","GEV_sigma","GEV_xi"]).to_csv(ROOT/"outputs/monthly_marginal_parameters.csv",index=False)
