#!/usr/bin/env python
from pathlib import Path
import json,sys
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.io_data import load_hindcast
from src.monthly_extremes import construct_monthly_extreme_pairs
from src.copulas import pseudo_observations,fit_single,fit_mixed,information_criteria,sn_statistic
from src.diagnostics import holdout_score,parametric_bootstrap_pvalue

cfg=json.load(open(ROOT/"analysis_config.json"))
df=load_hindcast(ROOT/"data")
monthly=construct_monthly_extreme_pairs(df)
models=["Gaussian","StudentT","Frank","Clayton","Gumbel","Mixed"]

# Long-term hourly pair diagnostics (Table 5 style)
rows=[]
for label,xcol,ycol in [("U10-Hs","U10","Hs"),("U10-Tp","U10","Tp"),("Hs-Tp","Hs","Tp")]:
    x=df[xcol].to_numpy(); y=df[ycol].to_numpy(); uv=pseudo_observations(x,y)
    train=df[(df.time.dt.year>=2002)&(df.time.dt.year<=2016)]
    test=df[(df.time.dt.year>=2018)&(df.time.dt.year<=2020)]
    for name in models:
        m=fit_mixed(uv,cfg["random_seed"]) if name=="Mixed" else fit_single(name,uv)
        k=5 if name=="Mixed" else len(m["params"])
        ic=information_criteria(m["loglik"],len(uv),k)
        hs,_=holdout_score(train[xcol].to_numpy(),train[ycol].to_numpy(),test[xcol].to_numpy(),test[ycol].to_numpy(),name,cfg["random_seed"])
        rows.append([label,name,m["loglik"],ic["AIC"],ic["BIC"],hs])
pd.DataFrame(rows,columns=["pair","copula","logL","AIC","BIC","holdout_mean_logL"]).to_csv(ROOT/"outputs/copula_long_term.csv",index=False)

# Monthly extreme pairs (Table 6 style)
rows=[]
for label,xcol,ycol in [("U10max-Hs","U10max","Hs_at_U10max"),("U10max-Tp","U10max","Tp_at_U10max"),("Hsmax-Tp","Hsmax","Tp_at_Hsmax")]:
    x=monthly[xcol].to_numpy(); y=monthly[ycol].to_numpy(); uv=pseudo_observations(x,y)
    train=monthly[(monthly.year>=2002)&(monthly.year<=2016)]
    test=monthly[(monthly.year>=2018)&(monthly.year<=2020)]
    for name in models:
        m=fit_mixed(uv,cfg["random_seed"]) if name=="Mixed" else fit_single(name,uv)
        k=5 if name=="Mixed" else len(m["params"])
        ic=information_criteria(m["loglik"],len(uv),k); sn=sn_statistic(uv,m)
        hs,_=holdout_score(train[xcol].to_numpy(),train[ycol].to_numpy(),test[xcol].to_numpy(),test[ycol].to_numpy(),name,cfg["random_seed"])
        p,_=parametric_bootstrap_pvalue(uv,m,B=cfg["bootstrap_replicates"],seed=cfg["random_seed"])
        rows.append([label,name,sn,m["loglik"],ic["AIC"],ic["BIC"],hs,p])
        print(label,name,"Sn",sn,"BIC",ic["BIC"],"holdout",hs,"bootstrap p",p)
pd.DataFrame(rows,columns=["pair","copula","Sn","logL","AIC","BIC","holdout_mean_logL","bootstrap_p"]).to_csv(ROOT/"outputs/copula_monthly_extremes.csv",index=False)
