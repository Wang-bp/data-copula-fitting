#!/usr/bin/env python
from pathlib import Path
import json,sys
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.io_data import load_hindcast
from src.monthly_extremes import construct_monthly_extreme_pairs
from src.marginals import LogKDE,KernelPareto,GEV
from src.copulas import pseudo_observations,fit_single
from src.return_periods import fixed_equal_univariate_thresholds,joint_return_period,balanced_physical_point

cfg=json.load(open(ROOT/"analysis_config.json")); pp=json.load(open(ROOT/"paper_parameters.json"))
df=load_hindcast(ROOT/"data"); mon=construct_monthly_extreme_pairs(df)
mu=cfg["monthly_interval_years"]
periods=cfg["return_periods_years"]

pairdefs={
 "U10max-Hs":("U10max","Hs_at_U10max","StudentT"),
 "U10max-Tp":("U10max","Tp_at_U10max","StudentT"),
 "Hsmax-Tp":("Hsmax","Tp_at_Hsmax","Gumbel"),
}

def paper_mixed(label):
    d=pp["monthly_mixed_copula_reported"][label]
    theta=[(1.0 if x is None and i==0 else 1e-3 if x is None else x) for i,x in enumerate(d["theta"])]
    return {"name":"Mixed","weights":d["weights"],"theta":theta}

fixed=[]; balanced=[]
for label,(xc,yc,bic_name) in pairdefs.items():
    x=mon[xc].to_numpy(); y=mon[yc].to_numpy()
    mx=LogKDE.fit(x,h=pp["monthly_sj_dpi_log_bandwidth"][xc]); my=LogKDE.fit(y,h=pp["monthly_sj_dpi_log_bandwidth"][yc])
    uv=pseudo_observations(x,y)
    fitted={name:fit_single(name,uv) for name in ["StudentT","Gumbel","Gaussian"]}
    fitted["Mixed"]=paper_mixed(label)
    for Tu in periods:
        xv,yv,u,v=fixed_equal_univariate_thresholds(mx,my,Tu,mu)
        for definition in ["OR","AND"]:
            for name,model in fitted.items():
                Tj=joint_return_period(model,u,v,definition,mu)
                fixed.append([label,definition,Tu,xv,yv,name,Tj])
    # balanced points for marginal sensitivity, keeping BIC-preferred copula fixed
    dep=fitted[bic_name]
    for definition in ["OR","AND"]:
        for T in [50,100]:
            for marg_name in ["SJ-DPI","Kernel-Pareto","GEV"]:
                if marg_name=="SJ-DPI": ax,ay=mx,my
                elif marg_name=="Kernel-Pareto": ax,ay=KernelPareto.fit(x,.95),KernelPareto.fit(y,.95)
                else: ax,ay=GEV.fit(x),GEV.fit(y)
                q,xx,yy=balanced_physical_point(dep,ax,ay,T,definition,mu)
                balanced.append([label,definition,T,marg_name,q,xx,yy])

pd.DataFrame(fixed,columns=["pair","definition","Tu_years","x_threshold","y_threshold","copula","joint_return_period_years"]).to_csv(ROOT/"outputs/fixed_threshold_joint_return_periods.csv",index=False)
pd.DataFrame(balanced,columns=["pair","definition","T_years","marginal","q","x","y"]).to_csv(ROOT/"outputs/marginal_sensitivity_balanced_points.csv",index=False)
