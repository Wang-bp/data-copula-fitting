#!/usr/bin/env python
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.io_data import load_hindcast
from src.monthly_extremes import construct_monthly_extreme_pairs,add_regime
from src.marginals import LogKDE
from src.copulas import pseudo_observations,fit_single,information_criteria,model_cdf
from src.diagnostics import seasonal_distribution_test,serial_diagnostics
from src.return_periods import fixed_equal_univariate_thresholds,joint_return_period

cfg=json.load(open(ROOT/"analysis_config.json")); pp=json.load(open(ROOT/"paper_parameters.json")); mu=cfg["monthly_interval_years"]
mon=add_regime(construct_monthly_extreme_pairs(load_hindcast(ROOT/"data")))
variables=["U10max","Hs_at_U10max","Tp_at_U10max","Hsmax","Tp_at_Hsmax"]
rows=[]
for v in variables:
    cool=mon.loc[mon.regime=="cool",v].to_numpy(); warm=mon.loc[mon.regime=="warm",v].to_numpy()
    D,p=seasonal_distribution_test(cool,warm); r,lp=serial_diagnostics(mon[v].to_numpy())
    rows.append([v,len(cool),cool.mean(),len(warm),warm.mean(),D,p,r,lp])
pd.DataFrame(rows,columns=["variable","cool_N","cool_mean","warm_N","warm_mean","KS_D","KS_p","lag1_r","LjungBox_p"]).to_csv(ROOT/"outputs/seasonality_serial_diagnostics.csv",index=False)

# Two-regime joint-return sensitivity at fixed pooled SJ-DPI thresholds.
pairdefs={"U10max-Hs":("U10max","Hs_at_U10max"),"U10max-Tp":("U10max","Tp_at_U10max"),"Hsmax-Tp":("Hsmax","Tp_at_Hsmax")}
out=[]
for label,(xc,yc) in pairdefs.items():
    pooled_x=LogKDE.fit(mon[xc],h=pp["monthly_sj_dpi_log_bandwidth"][xc]); pooled_y=LogKDE.fit(mon[yc],h=pp["monthly_sj_dpi_log_bandwidth"][yc])
    uv_pool=pseudo_observations(mon[xc],mon[yc])
    # BIC-best single within pooled sample
    cand=[]
    for name in ["Gaussian","StudentT","Gumbel","Clayton","Frank"]:
        mm=fit_single(name,uv_pool); k=len(mm["params"]); cand.append((information_criteria(mm["loglik"],len(uv_pool),k)["BIC"],mm))
    pool_model=min(cand,key=lambda z:z[0])[1]
    reg={}
    for rr in ["cool","warm"]:
        g=mon[mon.regime==rr]; uv=pseudo_observations(g[xc],g[yc]); cc=[]
        for name in ["Gaussian","StudentT","Gumbel","Clayton","Frank"]:
            mm=fit_single(name,uv); cc.append((information_criteria(mm["loglik"],len(uv),len(mm["params"]))["BIC"],mm))
        reg[rr]=min(cc,key=lambda z:z[0])[1]
    for Tu in [10,50,100]:
        xv,yv,u,v=fixed_equal_univariate_thresholds(pooled_x,pooled_y,Tu,mu)
        for definition in ["OR","AND"]:
            pooled_T=joint_return_period(pool_model,u,v,definition,mu)
            def prob(model):
                C=float(model_cdf(model,u,v))
                return 1-C if definition=="OR" else 1-u-v+C
            annual_rate=5*prob(reg["cool"])+7*prob(reg["warm"])
            seasonal_T=1/max(annual_rate,1e-15)
            out.append([label,Tu,definition,pooled_T,seasonal_T,100*(seasonal_T/pooled_T-1)])
pd.DataFrame(out,columns=["pair","Tu_years","definition","pooled_T","seasonal_T","delta_pct"]).to_csv(ROOT/"outputs/seasonal_joint_sensitivity.csv",index=False)
