#!/usr/bin/env python
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.io_data import load_hindcast,save_csv
from src.monthly_extremes import construct_monthly_extreme_pairs,add_regime

df=load_hindcast(ROOT/"data")
monthly=add_regime(construct_monthly_extreme_pairs(df,require_complete_month=True))
print(f"Hourly common-valid N = {len(df):,}")
print(f"Monthly extreme-pair N = {len(monthly)}")
save_csv(monthly,ROOT/"outputs/monthly_extreme_pairs.csv")
