#!/usr/bin/env python
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from src.io_data import load_hindcast
from src.monthly_extremes import construct_monthly_extreme_pairs
from src.marginals import LogKDE,KernelPareto,GEV,mean_residual_life,gpd_parameter_stability

cfg=json.load(open(ROOT/"analysis_config.json")); df=load_hindcast(ROOT/"data")
# Figure 4-style marginal PDFs (compact reproducibility version)
fig,axs=plt.subplots(1,3,figsize=(12,3.8))
for ax,var in zip(axs,["U10","Hs","Tp"]):
    x=df[var].to_numpy(); sj=LogKDE.fit(x,r_script=ROOT/"R/sj_dpi_bandwidth.R"); kp=KernelPareto.fit(x,.95); gev=GEV.fit(x)
    grid=np.linspace(max(1e-5,np.min(x)*.8),np.max(x)*1.03,300)
    ax.hist(x,bins=60,density=True,alpha=.25,label="Empirical")
    ax.plot(grid,sj.pdf(grid),label="SJ-DPI")
    ax.plot(grid,kp.pdf(grid),label="Kernel-Pareto")
    ax.plot(grid,gev.pdf(grid),label="GEV")
    ax.axvline(kp.threshold,ls=":",lw=1)
    ax.set_xlabel(var); ax.set_ylabel("Density")
axs[0].legend(frameon=False)
fig.tight_layout(); fig.savefig(ROOT/"outputs/Figure_marginal_PDFs.png",dpi=400); plt.close(fig)

# Kernel-Pareto threshold diagnostics (Figure S3-style)
fig,axs=plt.subplots(3,2,figsize=(9,10))
for i,var in enumerate(["U10","Hs","Tp"]):
    x=df[var].to_numpy(); mrl=np.array(mean_residual_life(x),dtype=float); stab=np.array(gpd_parameter_stability(x),dtype=float)
    axs[i,0].plot(mrl[:,0]*100,mrl[:,3],marker="o",ms=3); axs[i,0].axvline(95,ls=":"); axs[i,0].set_ylabel(f"{var}: mean excess")
    axs[i,1].plot(stab[:,0]*100,stab[:,3],marker="o",ms=3,label="xi"); axs[i,1].axvline(95,ls=":"); axs[i,1].set_ylabel(f"{var}: GPD shape xi")
for ax in axs[-1,:]: ax.set_xlabel("Threshold percentile (%)")
fig.tight_layout(); fig.savefig(ROOT/"outputs/Figure_KP_threshold_diagnostics.png",dpi=400); plt.close(fig)
